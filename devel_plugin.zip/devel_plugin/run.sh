[ ! -f /nova/etc/devel-login ] && echo "dd" > /nova/etc/devel-login
/bin/chmod +x /rw/pckg/plugin/devel/busybox
[ ! -f /sbin/ifconfig ] && /rw/pckg/plugin/devel/busybox --install 2>&1
[ ! -f /bin/top ] && ln -s /rw/pckg/plugin/devel/busybox /bin/top
