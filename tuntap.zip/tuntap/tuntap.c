#include <sys/types.h>

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <strsafe.h>

#include "tuntap.h"
#include "private.h"

#define TAP_CONTROL_CODE(request,method) CTL_CODE(FILE_DEVICE_UNKNOWN, request, method, FILE_ANY_ACCESS)
#define TAP_IOCTL_GET_MAC               TAP_CONTROL_CODE (1,  METHOD_BUFFERED)
#define TAP_IOCTL_GET_VERSION           TAP_CONTROL_CODE (2,  METHOD_BUFFERED)
#define TAP_IOCTL_GET_MTU               TAP_CONTROL_CODE (3,  METHOD_BUFFERED)
#define TAP_IOCTL_GET_INFO              TAP_CONTROL_CODE (4,  METHOD_BUFFERED)
#define TAP_IOCTL_CONFIG_POINT_TO_POINT TAP_CONTROL_CODE (5,  METHOD_BUFFERED)
#define TAP_IOCTL_SET_MEDIA_STATUS      TAP_CONTROL_CODE (6,  METHOD_BUFFERED)
#define TAP_IOCTL_CONFIG_DHCP_MASQ      TAP_CONTROL_CODE (7,  METHOD_BUFFERED)
#define TAP_IOCTL_GET_LOG_LINE          TAP_CONTROL_CODE (8,  METHOD_BUFFERED)
#define TAP_IOCTL_CONFIG_DHCP_SET_OPT   TAP_CONTROL_CODE (9,  METHOD_BUFFERED)
#define TAP_IOCTL_CONFIG_TUN            TAP_CONTROL_CODE (10, METHOD_BUFFERED)

#define MAX_KEY_LENGTH 255
#define MAX_VALUE_NAME 16383
#define NETWORK_ADAPTERS "SYSTEM\\CurrentControlSet\\Control\\Class\\{4D36E972-E325-11CE-BFC1-08002BE10318}"

typedef unsigned long IPADDR;

static char *reg_query(char *key_name) {
	HKEY adapters, adapter;
	DWORD i, ret, len;
	char *deviceid = NULL;
	DWORD sub_keys = 0;
	/*打开注册表项*/
	ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE, key_name, 0, KEY_READ, &adapters);
	if (ret != ERROR_SUCCESS)
		return NULL;
	/*读取子项*/
	ret = RegQueryInfoKey(adapters,	NULL, NULL, NULL, &sub_keys, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
	if (ret != ERROR_SUCCESS)
		return NULL;
	if (sub_keys <= 0)
		return NULL;
	/*遍历子项*/
    for (i = 0; i < sub_keys; i++) {
		char new_key[MAX_KEY_LENGTH];
		char data[256];
		TCHAR key[MAX_KEY_LENGTH];
		DWORD keylen = MAX_KEY_LENGTH;
		ret = RegEnumKeyEx(adapters, i, key, &keylen, NULL, NULL, NULL, NULL);
		if (ret != ERROR_SUCCESS)
			continue;
		snprintf(new_key, sizeof new_key, "%s\\%s", key_name, key);
		ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE, new_key, 0, KEY_READ, &adapter);
		if (ret != ERROR_SUCCESS)
			continue;
		len = sizeof data;
		ret = RegQueryValueEx(adapter, "ComponentId", NULL, NULL, (LPBYTE)data, &len);
		if (ret != ERROR_SUCCESS)
			goto clean;
		if (strncmp(data, "tap", 3) == 0) {
			DWORD type;
			len = sizeof data;
			ret = RegQueryValueEx(adapter, "NetCfgInstanceId", NULL, &type, (LPBYTE)data, &len);
			if (ret != ERROR_SUCCESS)
				goto clean;
			deviceid = strdup(data);
			break;
		}
clean:
		RegCloseKey(adapter);
	}
	RegCloseKey(adapters);
	return deviceid;
}

int tuntap_start(struct device *dev) {
	HANDLE tun_fd;
	char *deviceid;
	char buf[64];
	if (dev->tun_fd != TUNFD_INVALID_VALUE)
		return -1;
	deviceid = reg_query(NETWORK_ADAPTERS);
	snprintf(buf, sizeof buf, "\\\\.\\Global\\%s.tap", deviceid);
	tun_fd = CreateFile(buf, GENERIC_WRITE | GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_SYSTEM|FILE_FLAG_OVERLAPPED, 0);
	if (tun_fd == TUNFD_INVALID_VALUE)
		return -1;
	dev->tun_fd = tun_fd;
	return 0;
}

void tuntap_release(struct device *dev) {
	(void)CloseHandle(dev->tun_fd);
	free(dev);
}

char *tuntap_get_hwaddr(struct device *dev) {
	static unsigned char hwaddr[ETHER_ADDR_LEN];
	DWORD len;
    if (DeviceIoControl(dev->tun_fd, TAP_IOCTL_GET_MAC, &hwaddr, sizeof(hwaddr), &hwaddr, sizeof(hwaddr), &len, NULL) == 0)
		return NULL;
    else
		return (char*)hwaddr;
}

static int tuntap_set_updown(struct device *dev, ULONG flag) {
	DWORD len;
	if (DeviceIoControl(dev->tun_fd, TAP_IOCTL_SET_MEDIA_STATUS, &flag, sizeof(flag), &flag, sizeof(flag), &len, NULL) == 0)
		return -1;
    else
		return 0;
}

int tuntap_up(struct device *dev) {
	ULONG flag;
	flag = 1;
	return tuntap_set_updown(dev, flag);
}

int tuntap_down(struct device *dev) {
	ULONG flag;
	flag = 0;
	return tuntap_set_updown(dev, flag);
}

int tuntap_get_mtu(struct device *dev) {
	ULONG mtu;
	DWORD len;
	if (DeviceIoControl(dev->tun_fd, TAP_IOCTL_GET_MTU, &mtu, sizeof(mtu), &mtu, sizeof(mtu), &len, NULL) == 0)
		return -1;
	return 0;
}

int tuntap_set_mtu(struct device *dev, int mtu) {
	/* call netsh */
	return -1;
}

int tuntap_set_ipv4(struct device *dev, t_tun_in_addr *s, uint32_t mask) {
	IPADDR psock[2];
	DWORD len;
	psock[0] = s->S_un.S_addr;
	psock[1] = mask;
	if (DeviceIoControl(dev->tun_fd, TAP_IOCTL_CONFIG_POINT_TO_POINT, &psock, sizeof(psock), &psock, sizeof(psock), &len, NULL) == 0)
		return -1;
	return 0;
}

int tuntap_read(struct device *dev, void *buf, size_t size) {
	DWORD len;
	if (ReadFile(dev->tun_fd, buf, (DWORD)size, &len, NULL) == 0)
		return -1;
	return (int)len;
}

int tuntap_write(struct device *dev, void *buf, size_t size) {
	DWORD len;
	if (WriteFile(dev->tun_fd, buf, (DWORD)size, &len, NULL) == 0)
		return -1;
	return (int)len;
}
