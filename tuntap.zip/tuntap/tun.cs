using System;
using System.IO;
using System.Threading;
using System.Management;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace TunMirror
{
    class TunTap
    {
        private static int _bytesRead;
        private static FileStream _tap;
        private static EventWaitHandle _waitObject;
        private static EventWaitHandle _waitObject2;
        private const uint FileAnyAccess = 0;
        private const int FileAttributeSystem = 4;
        private const uint FileDeviceUnknown = 0x22;
        private const int FileFlagOverlapped = 0x40000000;
        private const uint MethodBuffered = 0;

        public string Local;
        public string Remote;

        public TunTap(string local, string remote)
        {
            Local = local;
            Remote = remote;
        }

        [DllImport("Kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CreateFile(string filename, [MarshalAs(UnmanagedType.U4)] FileAccess fileaccess, [MarshalAs(UnmanagedType.U4)] FileShare fileshare, int securityattributes, [MarshalAs(UnmanagedType.U4)] FileMode creationdisposition, int flags, IntPtr template);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true, ExactSpelling = true)]
        private static extern bool DeviceIoControl(IntPtr hDevice, uint dwIoControlCode, IntPtr lpInBuffer, uint nInBufferSize, IntPtr lpOutBuffer, uint nOutBufferSize, out int lpBytesReturned, IntPtr lpOverlapped);

        private static uint CtlCode(uint deviceType, uint function, uint method, uint access)
        {
            return ((((deviceType << 0x10) | (access << 14)) | (function << 2)) | method);
        }

        private static string GetDeviceGuid()
        {
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(@"root\CIMV2", "SELECT GUID FROM Win32_NetworkAdapter WHERE ServiceName = 'tap0901'");
            foreach (ManagementObject obj2 in searcher.Get())
            {
                if (obj2["GUID"].ToString() != string.Empty)
                    return obj2["GUID"].ToString();
            }
            return string.Empty;
        }

        private static uint TapControlCode(uint request, uint method)
        {
            return CtlCode(0x22, request, method, 0);
        }

        public static Int32 IPInfoToInt32(string s)
        {
            Regex regex = new Regex(@"\d+\.\d+\.\d+\.\d+");
            if (!regex.IsMatch(s))
            {
                Console.WriteLine(String.Format("{0}格式有误", s));
                Environment.Exit(1);
            }
            string[] sList = s.Split('.');
            Int32 ret = 0;
            try
            {
                for (int i = 0; i < 4; i++)
                {
                    Int32 j = System.Convert.ToInt32(sList[i]);
                    if (j > 255) { throw new FormatException(); }
                    ret += j * (int)Math.Pow(256, i);
                }
            }
            catch (FormatException)
            {
                Console.WriteLine(String.Format("{0}格式有误", s));
                Environment.Exit(1);
            }
            return ret;
        }

        [STAThread]
        public void ThreadLoop()
        {
            int num;
            string deviceGuid = GetDeviceGuid();
            IntPtr hDevice = CreateFile(@"\\.\Global\" + deviceGuid + ".tap", FileAccess.ReadWrite, FileShare.ReadWrite, 0, FileMode.Open, 0x40000004, IntPtr.Zero);
            IntPtr ptr = Marshal.AllocHGlobal(4);
            Marshal.WriteInt32(ptr, 1);
            DeviceIoControl(hDevice, TapControlCode(6, 0), ptr, 4, ptr, 4, out num, IntPtr.Zero);
            IntPtr ptr3 = Marshal.AllocHGlobal(8);
            Int32 ip = IPInfoToInt32(IP);
            Int32 mask = IPInfoToInt32(MASK);
            Marshal.WriteInt32(ptr3, 0, Local);
            Marshal.WriteInt32(ptr3, 4, Remote);
            DeviceIoControl(hDevice, TapControlCode(5, 0)/*POINT_TO_POINT*/, ptr3, 8, ptr3, 8, out num, IntPtr.Zero);
            _tap = new FileStream(new SafeFileHandle(hDevice, true), FileAccess.ReadWrite, 0x2710, true);//0x2710 is buffer size
            byte[] buffer = new byte[0x2710];
            object state = 0;
            _waitObject = new EventWaitHandle(false, EventResetMode.AutoReset);
            object obj3 = 0;
            _waitObject2 = new EventWaitHandle(false, EventResetMode.AutoReset);
            AsyncCallback callback = new AsyncCallback(TunTap.ReadDataCallback);
            AsyncCallback callback2 = new AsyncCallback(TunTap.WriteDataCallback);
            while (Thread.CurrentThread.IsAlive)
            {
                _tap.BeginRead(buffer, 0, 0x2710, callback, state);
                _waitObject.WaitOne();
                string src = String.Format("{0}.{1}.{2}.{3}", buffer[12], buffer[13], buffer[14], buffer[15]);
                string dst = String.Format("{0}.{1}.{2}.{3}", buffer[16], buffer[17], buffer[18], buffer[19]);
                string srcPort = String.Format("{0}", Convert.ToInt32(buffer[20]) * 256 + Convert.ToInt32(buffer[21]));
                string dstPort = String.Format("{0}", Convert.ToInt32(buffer[22]) * 256 + Convert.ToInt32(buffer[23]));
                for (int i = 0; i < 4; i++)
                {
                    byte num3 = buffer[12 + i];
                    buffer[12 + i] = buffer[0x10 + i];
                    buffer[0x10 + i] = num3;
                }
                _tap.BeginWrite(buffer, 0, _bytesRead, callback2, obj3);
                _waitObject2.WaitOne();
            }
        }

        public static void ReadDataCallback(IAsyncResult asyncResult)
        {
            try
            {
                _bytesRead = _tap.EndRead(asyncResult);
            }
            catch
			{
				
			}
            _waitObject.Set();
        }

        public static void WriteDataCallback(IAsyncResult asyncResult)
        {
            try
            {
                _tap.EndWrite(asyncResult);
            }
            catch
			{
				
			}
            _waitObject2.Set();
        }
    }
}
