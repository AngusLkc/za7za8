#include <sys/types.h>
#include <stdint.h>

#ifndef PRIVATE_H_
#define PRIVATE_H_

#define TUNFD_INVALID_VALUE INVALID_HANDLE_VALUE

typedef IN_ADDR t_tun_in_addr;

struct device {
	t_tun			tun_fd;
	int				ctrl_sock;
	int				flags;
	unsigned char	hwaddr[ETHER_ADDR_LEN];
	char			if_name[IF_NAMESIZE + 1];
};

#define snprintf(x, y, z, ...) _snprintf_s((x), (y), (y), (z), __VA_ARGS__);
#define strncat(x, y, z) strncat_s((x), _countof(x), (y), (z));
#define strdup(x) _strdup(x)

int tuntap_start(struct device *, int, int);
int tuntap_set_ipv4(struct device *, t_tun_in_addr *, uint32_t);

#endif
