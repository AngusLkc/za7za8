#include <sys/types.h>

#ifndef LIBTUNTAP_H_
#define LIBTUNTAP_H_

#ifdef __cplusplus
extern "C" {
#endif

struct device {
	t_tun			tun_fd;
	int				ctrl_sock;
	int				flags;
	unsigned char	hwaddr[ETHER_ADDR_LEN];
	char			if_name[IF_NAMESIZE + 1];
};

TUNTAP_EXPORT struct device	*tuntap_init(void);
TUNTAP_EXPORT int	 tuntap_start(struct device *, int, int);
TUNTAP_EXPORT void	 tuntap_release(struct device *);
TUNTAP_EXPORT char	*tuntap_get_hwaddr(struct device *);
TUNTAP_EXPORT int	 tuntap_up(struct device *);
TUNTAP_EXPORT int	 tuntap_down(struct device *);
TUNTAP_EXPORT int	 tuntap_get_mtu(struct device *);
TUNTAP_EXPORT int	 tuntap_set_mtu(struct device *, int);
TUNTAP_EXPORT int	 tuntap_set_ipv4(struct device *, const char *, int);
TUNTAP_EXPORT int	 tuntap_read(struct device *, void *, size_t);
TUNTAP_EXPORT int	 tuntap_write(struct device *, void *, size_t);

#ifdef __cplusplus
}
#endif
#endif
