#root@szlznet:~# ./radiusbypass -h
#RADIUS AAA By Pass Authentication Tool.
#Usage: 
#Daemon Mode:radiusbypass -p 1812 -s 123456 -u 1536 -d 10240 -t 86400 -f logfile.txt -D
#   or: 
#Console Mode:radiusbypass -p 1812 -s 123456 -u 1536 -d 10240 -t 86400 -f logfile.txt
#
#    -h, --help                    show this help message and exit
#    -D, --daemon                  Daemon Mode
#    -p, --port=<int>              Listen Port
#    -u, --uplimit=<int>           Upload Limit
#    -d, --downlimit=<int>         Down Limit
#    -t, --session_simeout=<int>   Session Timeout
#    -s, --secret=<str>            Auth Secret
#    -f, --logfile=<str>           LOG FILE
#

/bin/chmod +x /rw/pckg/plugin/radiusbypass/radius
/rw/pckg/plugin/radiusbypass/radius -p 1812 -s 123456 -f /rw/pckg/plugin/radiusbypass/logfile.txt -D
